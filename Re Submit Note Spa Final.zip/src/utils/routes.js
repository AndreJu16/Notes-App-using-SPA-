export const HOME = "/";
export const ARCHIVES = "/archives";
export const NOTES_DETAIL = "/notes/:id"
export const EDIT_NOTES = "/notes/edit/:id";
export const NEW_NOTES ="/notes/new";
export const PAGE_NOT_FOUND ="*"